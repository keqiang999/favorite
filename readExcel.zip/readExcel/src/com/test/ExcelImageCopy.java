package com.test;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;

import javax.imageio.ImageIO;

public class ExcelImageCopy {
	public static void main(String[] args){
		FileOutputStream fileout = null;
		BufferedImage bufferImage = null;
		try{
			ByteArrayOutputStream byteArrayOut = new ByteArrayOutputStream();
			bufferImg = ImageIO.read(new File(""));
			}
		catch(){
			
		}
		finally{}
	}
}
