package com.test;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;

public class ExcelReader {

	public static final String SAMPLE_XLSX_FILE_PATH = "./tmp.xlsx";
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException , InvalidFormatException{
		File file = new File("newFile.txt");
		boolean flg =  file.createNewFile();
		if(!flg){
			file.delete();
			flg = file.createNewFile();
		}
		System.out.println("nowPath:"+flg+":"+file.getAbsolutePath()+":"+file.getCanonicalPath());
		
		Workbook workbook = WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));
		System.out.println("Workbook has " + workbook.getNumberOfSheets()+"Sheets :");
		Iterator sheetIterator = workbook.sheetIterator();
		System.out.println("Retrieving Sheets using Iterator");
		while(sheetIterator.hasNext()){
			Sheet sheet = (Sheet) sheetIterator.next();
			System.out.println("=>" + sheet.getSheetName());
		}
		System.out.println("Retrieving Sheets");
//		for(Sheet sheet:workbook){
//			System.out.println("=>" + sheet.getSheetName());
//		}
//		System.out.println("Retrieving Sheets using Java 8 forEach with lamda");
//		workbook.forEach(sheet ->{
//			System.out.println("=>"+ sheet.getSheetName());
//		});

		Sheet sheet = workbook.getSheetAt(1);
		DataFormatter dataFormatter = new DataFormatter();
		Iterator rowIterator = sheet.rowIterator();
		while(rowIterator.hasNext()){
			Row row = (Row)rowIterator.next();
			Iterator cellIterator = row.cellIterator();
			while(cellIterator.hasNext()){
				Cell cell =(Cell) cellIterator.next();
				String cellValue = dataFormatter.formatCellValue(cell);
				System.out.println(cellValue+"\t");
			}
			System.out.println();
		}
		workbook.close();
	}
}
