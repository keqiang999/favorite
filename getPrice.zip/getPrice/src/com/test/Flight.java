package com.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;


public class Flight {
//    private static DB db ;
//    private static DBCollection emp2 ;
    
    static {
//        MongoClient mongo = new MongoClient("127.0.0.1", 27017);
//        // 选择集合存取
//        db = mongo.getDB("taobao");
//        emp2 = db.getCollection("cityCode2");
    }
    /*
     * 根据url获取机票的信息 注意 这里的机票信息 暂时定义的是当天的最低价
     */
    public static void getFlightInfo(String url) {
        // 这里根据url获取返回的数据
        String str = QueryCityCode.getCodeJson(url);
        //System.out.println(str);
        // 解析返回的字符串 并返回json对象
        JSONObject jo = QueryCityCode.analysis(str);
        // 获取信息中我们需要的数据 ()
        JSONObject jof = JSON.parseObject(jo.getString("data"));
        // 获取 aircodeNameMap 信息
        JSONObject joAirInfo = JSON
                .parseObject(jof.getString("aircodeNameMap"));
        // 获取airportMap 机场信息
        JSONObject joAirPortInfo = JSON
                .parseObject(jof.getString("airportMap"));
        // 获取出发地信息以及目的地信息
        String depCityCode = jof.getString("depCityCode");
        String depCityName = jof.getString("depCityName");
        String arrCityCode = jof.getString("arrCityCode");
        String arrCityName = jof.getString("arrCityName");
        // 获取航班信息 flight 这里只获取最低价 取第一个
        JSONObject joFlight = JSON.parseArray(jof.getString("flight"))
                .getJSONObject(0);

        // 获取信息详情
        String airlineCode = joFlight.getString("airlineCode");// 航线信息
        String arrAirport = joFlight.getString("arrAirport");// 目的机场code
        String arrTime = joFlight.getString("arrTime");// 到达时间
        String depAirport = joFlight.getString("depAirport");// 出发机场code
        String depTime = joFlight.getString("depTime");// 出发时间
        String flightNo = joFlight.getString("flightNo");// 航班编号
        String stop = joFlight.getString("stop");// 是否有中转 1是0否
        // 获取机票价格信息 最低价
        JSONObject joP = JSON.parseObject(joFlight.getString("cabin"));
        String bestPrice = joP.getString("bestPrice");// 最低价格
        String cabinNum = joP.getString("cabinNum");// 票数
        String bestDiscount = joP.getString("bestDiscount");// 最高的折扣
        // 将信息存入数据库中
        
//        DBCollection emp = db.getCollection("sz-bj");
//        DBObject obj = new BasicDBObject();
//        obj.put("airlineCode", airlineCode);
//        obj.put("arrAirport", arrAirport);
//        obj.put("arrTime", arrTime);
//        obj.put("depAirport", depAirport);
//        obj.put("depTime", depTime);
//        obj.put("flightNo", flightNo);
//        obj.put("stop", stop);
//        obj.put("bestPrice", bestPrice);
//        obj.put("cabinNum", cabinNum);
//        obj.put("bestDiscount", bestDiscount);
//        obj.put("depCityCode", depCityCode);
//        obj.put("depCityName", depCityName);
//        obj.put("arrCityCode", arrCityCode);
//        obj.put("arrCityName", arrCityName);
//        emp.insert(obj);
    }
    /*
     * deptCity 出发城市
     * arrCity  目的城市
     * deptTime 出发时间
     */
    public static String updatURL(String deptCityName,String arrCityName,String deptTime){
        String url = "";
        // 这里需要根据城市的名称获取城市的code码
//        BasicDBObject queryObjectDept = new BasicDBObject("cityName",deptCityName);
//        DBObject objDept = emp2.findOne(queryObjectDept);
//        BasicDBObject queryObjectArr = new BasicDBObject("cityName",arrCityName);
//        DBObject objArr = emp2.findOne(queryObjectArr);
        // 判断是否存在这样的城市码 存在在进行下面的url拼接
//        if(objDept != null && objArr != null && !("".equals(deptTime))){
//            String depCityCode = (String) objDept.get("cityCode");
//            String arrCityCode = (String) objArr.get("cityCode");
//            url = "https://sjipiao.alitrip.com/searchow/search.htm" +
//                    "?_ksTS=1515770795165_176&callback=jsonp177&" +
//                    "tripType=0&depCity="+depCityCode+"&" +
//                    "depCityName="+deptCityName+"&" +
//                    "arrCity="+arrCityCode+"&arrCityName="+arrCityName+"&depDate="+deptTime;
//        }
       url = "https://sjipiao.fliggy.com/flight_search_result.htm?searchBy=1277&ttid=seo.000000573&tripType=0&depCityName=%C9%CF%BA%A3&depCity=SHA&depDate=2019-04-22&arrCityName=%B1%B1%BE%A9&arrCity=BJS&arrDate=&ttid=seo.000000573";
        return url;
    }
    
    /*
     * 转化日期并将时间加一天
     */
    public static String changeTimeFormat(String date){
        SimpleDateFormat sdf =   new SimpleDateFormat( "yyyy-MM-dd" );
        Calendar c = Calendar.getInstance();  
        String time = "";
        try {
            Date d = sdf.parse(date);
            c.setTime(d);
            c.add(Calendar.DATE, 1);
            Date tomorrow = c.getTime();
            time = sdf.format(tomorrow);
            return time;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return time;
    }
    
    public static void main(String[] args) {
        //String url = "https://sjipiao.alitrip.com/searchow/search.htm?_ksTS=1515770795165_176&callback=jsonp177&tripType=0&depCity=SZX&depCityName=%E6%B7%B1%E5%9C%B3&arrCity=BJS&arrCityName=%E5%8C%97%E4%BA%AC&depDate=2018-01-19";
//    	String url =  "https://sjipiao.fliggy.com/flight_search_result.htm?searchBy=1277&ttid=seo.000000573&tripType=0&depCityName=%C9%CF%BA%A3&depCity=SHA&depDate=2019-04-22&arrCityName=%B1%B1%BE%A9&arrCity=BJS&arrDate=&ttid=seo.000000573";
//    	String url ="https://flights.ctrip.com/itinerary/oneway/sha-bjs?date=2019-04-22";
    	//        DBCursor dbc = emp2.find();
        String deptName = "深圳";
//        while(dbc.hasNext()){
//            DBObject obj = dbc.next();
            // 过滤 出发地
//            String arrCityName = (String) obj.get("cityName");
//            if(!deptName.equals(arrCityName)){
                String time = "2019-04-22";
//                for(int i=0;i<30;i++){
//                    String url = updatURL(deptName,arrCityName,time);
                    String url1 = updatURL(deptName,"北京",time);
                    getFlightInfo(url1);
                    System.out.println("success");
//                    System.out.println(deptName+"==>"+arrCityName+time+"机票信息数据抓取成功");

                    time = changeTimeFormat(time);
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
//                }
            }
//        }
        
//   }

}
