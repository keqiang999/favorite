package com.test;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class QueryCityCode {

	// private static MongoClient mongo = new MongoClient("127.0.0.1",27017);

	/**
	 * get cityCode from url
	 * 
	 */
	public static String getCodeJson(String url){
		String html = null;
		try{
			CloseableHttpClient httpClient = HttpClients.createDefault();
			HttpGet httpGet = new HttpGet(url);
			CloseableHttpResponse response = null;
			response = httpClient.execute(httpGet);
			HttpEntity entity = response.getEntity();
//			EntityUtils.toString(entity, "utf-8");
			html = EntityUtils.toString(entity, "UTF-8");
			response.close();
			httpClient.close();
			SslTest st = new SslTest();
			
		}catch (Exception e) {
            e.printStackTrace();
        }
            return html;
            
    }
    
    /*
     * 根据返回的字符串解析成Json对象
     */
    public static JSONObject analysis(String str){
        // 根据返回的字符串 分析并建立解析规则 
        int first = str.indexOf("(");
        int last  = str.lastIndexOf(")");
        if(first >=0 && last >0){
            String newStr = str.substring(first+1, last);
            return JSON.parseObject(newStr);
        }
        return  null;
    }
    
    /*
     * 解析JSON对象并将JSON对象存入mongodb中
     */
    public static void analysisJsonAndSave(JSONObject json){
        // 选择集合存取
//        DB  db =  mongo.getDB("taobao");
//        DBCollection emp = db.getCollection("cityCode2");
        // 利用aili的JSON包解析
        JSONArray datas = 
            JSON.parseArray((JSON.parseObject(JSON.parseObject(json.getString("267040"))
            .getString("value")).
            getString("cityArray")));
        // 这里说明一下为什么i=1因为第一个json数据不是我们想要的数据所以直接截掉
        for(int i=1;i<datas.size();i++){
            JSONObject jo = datas.getJSONObject(i);
            // 这里解析出来同样是一个JSON数组
            JSONArray joTemp = JSON.parseArray(jo.getString("tabdata"));
            // 在一层for循环
            for(int j=0;j<joTemp.size();j++){
                JSONObject joj = joTemp.getJSONObject(j);
                // 这是dd层的 下面就是我们最终需要的城市数据了
                JSONArray jsond = JSON.parseArray(joj.getString("dd"));
                for(int m=0;m < jsond.size();m++){
                    JSONObject jom = jsond.getJSONObject(m);
//                    DBObject obj = new BasicDBObject();
//                    obj.put("cityCode", jom.getString("cityCode"));
//                    obj.put("cityName", jom.getString("cityName"));
//                    obj.put("tce_rule_count", jom.getString("tce_rule_count"));
//                    obj.put("isVister", 0);//0表示未访问过 为后面获取机票信息准备
//                    emp.insert(obj);
//                    obj = null;
                }
            }
        }
    }}