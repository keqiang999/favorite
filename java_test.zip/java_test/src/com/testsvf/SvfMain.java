package com.testsvf;

public class SvfMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SvfBean sBean = new SvfBean();
//		sBean.setFrmFilePath("e:\\test.frm");
		sBean.setFormMode(5);
//		sBean.setPdfFilePath("H:/tmp/test.pdf");
		sBean.setPdfFilePath("H:\\tmp\\test.pdf");
		SvfPDFMake spMake = new SvfPDFMake();
		int ret = spMake.pdfPrint(sBean);
		System.out.println("ret value is:"+ret);
	}
}
