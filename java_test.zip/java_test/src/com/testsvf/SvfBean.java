package com.testsvf;

public class SvfBean {
	private String frmFilePath;
	private String pdfFilePath;
	private int formMode;
	public String getFrmFilePath() {
		return frmFilePath;
	}
	public void setFrmFilePath(String frmFilePath) {
		this.frmFilePath = frmFilePath;
	}
	public String getPdfFilePath() {
		return pdfFilePath;
	}
	public void setPdfFilePath(String pdfFilePath) {
		this.pdfFilePath = pdfFilePath;
	}
	public int getFormMode() {
		return formMode;
	}
	public void setFormMode(int formMode) {
		this.formMode = formMode;
	}
	
}
