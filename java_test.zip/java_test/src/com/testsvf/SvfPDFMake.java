package com.testsvf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import jp.co.fit.vfreport.Vrw32;

public class SvfPDFMake {
	Vrw32 vrw = new Vrw32();
	public int pdfPrint(SvfBean svfBean){
		int ret = 0;
		vrw.VrInit();
		vrw.VrSetPrinter("", "PDF");
		vrw.VrSetSpoolFileName2(svfBean.getPdfFilePath());
		vrw.VrSetForm(svfBean.getFrmFilePath(), svfBean.getFormMode());
		
		HashMap<String,String> headMap = new HashMap<String,String>();
		headMap.put("会社名", "XXXXXX株式会社");
		headMap.put("住所", "XXXXXXXXXXXX");
		headMap.put("電話番号", "xxxxxxxxxxxxxxx");
		headMap.put("支払条件", "xxxxxxxxxxxxxxx");
		headMap.put("納品場所", "南京");
		ArrayList listList = new ArrayList();
		for(int i=0;i<10;i++)
		{
			for(int j=0;j<2;j++)
			{
				HashMap listMap = new HashMap();
				listMap.put("商品コード", "IPHONE"+i);
				listMap.put("品番", "I"+i);
				listMap.put("数量", i);
				listMap.put("単価", j);
				listMap.put("明細番号", "1110"+i);
				listMap.put("備考", "備考"+i);
				listList.add(listMap);
			}
		}

		doheadDataPrint(headMap);
		dolistDataPrint(listList);
		ret = vrw.VrPrint();
		ret = vrw.VrQuit();
		return ret;
	}

	public void doheadDataPrint(HashMap headMap)
	{
		Iterator iterator = headMap.keySet().iterator();
		while(iterator.hasNext())
		{
			String fieldKey = (String)iterator.next();
			String fieldValue = headMap.get(fieldKey).toString();
			vrw.VrsOut(fieldKey, fieldValue);
		}
	}

	public void dolistDataPrint(ArrayList listList)
	{
		for(int i = 0; i < listList.size(); i++)
		{
			HashMap record = (HashMap)listList.get(i);
			Iterator iterator = record.keySet().iterator();
			while(iterator.hasNext())
			{
				String fieldKey = (String)iterator.next();
				String fieldValue = record.get(fieldKey).toString();
				vrw.VrsOut(fieldKey, fieldValue);
			}
			vrw.VrEndRecord();
		}
	}

}