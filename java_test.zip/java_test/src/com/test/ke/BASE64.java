package com.test.ke;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * @author keqiang
 *
 */
public class BASE64 {

	/**
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static byte[] decryptBASE64(final String key) throws Exception {
		return (new BASE64Decoder()).decodeBuffer(key);
	}

	/**
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String encryptBASE64(final byte[] key) throws Exception {
		return (new BASE64Encoder()).encodeBuffer(key);
	}

	/**
	 * @param args
	 */
	public static void main(final String[] args) {

		String str = "B";

		try {
			String result1 = BASE64.encryptBASE64(str.getBytes());
			System.out.println("result1===============" + result1);

			String str2 = new String(BASE64
					.decryptBASE64(result1));
			System.out.println("str2================" + str2);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
