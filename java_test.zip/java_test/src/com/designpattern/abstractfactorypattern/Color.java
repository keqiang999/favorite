package com.designpattern.abstractfactorypattern;

public interface Color {
	void fill();
}
