package com.designpattern.abstractfactorypattern;

import com.designpattern.factorypattern.Shape;

public abstract class AbstractFactory {
	public abstract Color getColor( String color);
	public abstract Shape getShape(String shape);
	
}
