package com.designpattern.singletonpattern;

public class Singletonpatterndemo {
	public static void main(String[] args){
		SingleObject object = SingleObject.getInstance();
		object.showMessage();
	}
}
