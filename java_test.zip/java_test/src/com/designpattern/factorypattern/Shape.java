package com.designpattern.factorypattern;

public interface Shape {
	void draw();
}
