package com.designpattern.decoratorpattern;

public class RedShapeDecorator extends ShapeDecorator{

}
