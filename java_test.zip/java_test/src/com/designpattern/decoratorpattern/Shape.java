package com.designpattern.decoratorpattern;

public interface Shape {
	void draw();
}
