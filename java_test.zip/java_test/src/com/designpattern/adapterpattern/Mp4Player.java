package com.designpattern.adapterpattern;

public class Mp4Player implements AdvancedMediaPlayer{

	public void playVlc(String fileName) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	public void playMp4(String fileName) {
		System.out.println("Playing mp4 file. Name: " + fileName);
		
	}

}
