package com.designpattern.builderpattern;

public abstract class Burger implements Item{
	public Packing packing(){
		return new Wrapper();
	}
	public abstract float price();
}
