package com.designpattern.builderpattern;

public class Pepsi extends ColdDrink{

	public String name() {
		// TODO 自動生成されたメソッド・スタブ
		return "Pepsi";
	}

	@Override
	public float price() {
		// TODO 自動生成されたメソッド・スタブ
		return 35.0f;
	}
	
}
