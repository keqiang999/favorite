package com.designpattern.builderpattern;

public class Wrapper implements Packing{

	public String pack() {
		
		return "Wrapper";
	}

}
