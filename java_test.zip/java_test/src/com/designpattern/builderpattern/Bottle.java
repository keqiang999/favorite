package com.designpattern.builderpattern;

public class Bottle implements Packing{

	public String pack() {
		return "Botte";
	}
	
}
