package com.designpattern.builderpattern;

public class ChickenBurger extends Burger{

	public String name() {
		// TODO 自動生成されたメソッド・スタブ
		return "Chicken Burger";
	}

	@Override
	public float price() {
		// TODO 自動生成されたメソッド・スタブ
		return 50.5f;
	}

}
