package com.designpattern.builderpattern;

public interface Packing {
	public String pack();
}
