package com.designpattern.builderpattern;

public class Coke extends ColdDrink{

	public String name() {
		// TODO 自動生成されたメソッド・スタブ
		return "Coke";
	}

	@Override
	public float price() {
		// TODO 自動生成されたメソッド・スタブ
		return 30.0f;
	}

}
