package jp.co.fit.vfreport;
import java.io.*;
import java.sql.Connection;
import java.text.MessageFormat;
import java.util.*;
import jp.c2software.documentparser.util.DocumentParserImplements;
import jp.co.fit.io.FileLocator;
import jp.co.fit.io.TemporaryFile;
import jp.co.fit.query.SqlDriver;
import jp.co.fit.util.FileProperties;
import jp.co.fit.util.NumberString;
public class Vrw0
    implements Svf
{
    private static class VR32TEST extends VR32MAIN
    {
        public int VrInit()
        {
            int i = super.VrInit();
            return i;
        }
        public int VrQuit()
        {
            int i = super.VrQuit();
            return i;
        }
        public int VrSetForm(String s, int i)
        {
            int j = super.VrSetForm(s, i);
            return j;
        }
        public int VrEndPage()
        {
            int i = 0;
            recCount = 0;
            return i;
        }
        public int VrsOut(String s, String s1)
        {
            return 0;
        }
        public int VrsOutn(String s, int i, String s1)
        {
            return 0;
        }
        public int VrAttribute(String s, String s1)
        {
            return 0;
        }
        public int VrAttributen(String s, int i, String s1)
        {
            return 0;
        }
        public int VrSetSubForm(String s)
        {
            return 0;
        }
        public int VrSetRecord(String s, int i)
        {
            return ++recCount % 10 != 0 ? 0 : -133;
        }
        public int VrCheckSpace(String s)
        {
            return 0;
        }
        private int recCount;
        public VR32TEST(Locale locale)
        {
            super(locale);
            recCount = 0;
        }
    }
    private void setSurrogateMap()
    {
        surrogatetbl = new Hashtable();
        StringTokenizer stringtokenizer = null;
        try
        {
            stringtokenizer = new StringTokenizer(new String(DocumentParserImplements.loadBytes("jar:
        }
        catch(Exception exception)
        {
            if(driver.isDebug())
                driver.warningOutput(exception, "xxxx");
        }
        Integer integer;
        Integer integer1;
        for(; stringtokenizer.hasMoreTokens(); surrogatetbl.put(integer1, integer))
        {
            integer = new Integer(Integer.parseInt(stringtokenizer.nextToken(), 16));
            integer1 = new Integer(Integer.parseInt(stringtokenizer.nextToken(), 16));
        }
    }
    public static char[] toSurrogatePair(int i)
    {
        return (new char[] {
            (char)(55296 | i - 65536 >> 10), (char)(56320 | i - 65536 & 1023)
        });
    }
    public static int toUnicode(char ac[])
    {
        return (ac[0] - 55296 << 10 | ac[1] - 56320) + 65536;
    }
    private char replace(char ac[])
    {
        Object obj = surrogatetbl.get(new Integer(toUnicode(ac)));
        if(obj == null)
            return ' ';
        else
            return (char)((Integer)obj).intValue();
    }
    private String replace(String s)
    {
        if(s == null)
            return null;
        StringBuilder stringbuilder = new StringBuilder();
        for(int i = 0; i < s.length(); i++)
        {
            char c = s.charAt(i);
            if(c >= '\uD800' && c <= '\uDBFF')
            {
                if(i - 1 == s.length())
                    stringbuilder.append(32);
                else
                    stringbuilder.append(replace(new char[] {
                        c, s.charAt(++i)
                    }));
            } else
            {
                stringbuilder.append(c);
            }
        }
        return stringbuilder.toString();
    }
    public Vrw0()
    {
        driver0 = null;
        driver = null;
        nests = 0;
        variables = new Hashtable();
        properties = new FileProperties();
        formLoaded = false;
        encoding = "";
        nullOutputCommand = "";
        nullCheckMode = false;
        batchObject = null;
        batchAllForms = false;
        batchReady = false;
        batchExecuting = false;
        batchSerialPageCount = 0;
        batchTotalPageCount = 0;
        execVrStackOut = false;
        execVrEndSendFax = false;
        execVrPreviewEndPage = false;
        execVrInit = false;
        spoolOutput = null;
        currentLocale = Locale.getDefault();
        formSubPageInfos = new Vector();
        formCount = 0;
        batchRequest = false;
        totalPagePrefixChar = "";
        surrogatetbl = null;
        showExceptions = false;
    }
    private void initInstance()
    {
        if(driver0 == null)
        {
            driver0 = new VR32MAIN(currentLocale);
            driver = new BasicDriverImpl(this, driver0, properties, variables);
            readRuntimeProperties();
        }
    }
    private void readRuntimeProperties()
    {
        FileProperties fileproperties = VrGetProperties();
        encoding = fileproperties.getProperty("Default.Encoding", encoding);
        nullOutputCommand = fileproperties.getProperty("ReportWriter", "NullOutputCommand", nullOutputCommand);
        nullCheckMode = fileproperties.getProperty("ReportWriter", "NullCheck", nullCheckMode);
        totalPagePrefixChar = fileproperties.getProperty("ReportWriter", "TotalPagePrefixChar", totalPagePrefixChar);
        if(fileproperties.getProperty("Unicode.SurrogateProcessing", false))
            setSurrogateMap();
    }
    public void close()
    {
        if(driver0 != null)
        {
            if(execVrInit)
            {
                driver.setOutputFailed(true);
                VrQuit();
            }
            closeBatch();
            deleteTemporaryFiles();
            if(driver != null)
                try
                {
                    driver.close();
                }
                catch(Throwable throwable)
                {
                    throwable.printStackTrace();
                }
        }
    }
    private void deleteTemporaryFiles()
    {
        if(spoolOutput != null)
        {
            spoolOutput = null;
            if(spoolFile == null)
            {
                (new File(driver.VrGetSpoolFileName())).delete();
            } else
            {
                spoolFile.delete();
                spoolFile = null;
            }
        }
    }
    private String checkNull(String s)
    {
        if(s == null)
            if(nullCheckMode)
                s = "";
            else
                throw new NullPointerException();
        return s;
    }
    private static String toStr(Object obj)
    {
        return obj != null ? NumberString.toString(obj) : "(null)";
    }
    private static String toStr(int i)
    {
        return NumberString.toString(i);
    }
    private static String toStr(long l)
    {
        return NumberString.toString(l);
    }
    private static String toStr(double d)
    {
        return NumberString.toString(d);
    }
    private static Locale toLocale(String s)
    {
        if(s == null || s.length() == 0)
            return Locale.getDefault();
        ArrayList arraylist = new ArrayList();
        for(StringTokenizer stringtokenizer = new StringTokenizer(s, "_-"); stringtokenizer.hasMoreTokens(); arraylist.add(stringtokenizer.nextToken()));
        for(; arraylist.size() < 3; arraylist.add(""));
        return new Locale(arraylist.get(0).toString(), arraylist.get(1).toString(), arraylist.get(2).toString());
    }
    Locale getCurrentLocale()
    {
        return currentLocale;
    }
    void initialize()
    {
        if(batchObject != null)
        {
            int i = -1;
            if(batchAllForms || driver.isTotalPageMode())
            {
                nullOutMode = true;
                i = driver.VrComout(MessageFormat.format(nullOutputCommand, new Object[] {
                    "1"
                }));
            }
            if(i >= 0)
            {
                if(!batchReady)
                {
                    formCount++;
                    driver.warningOutput(null, "start of batch print mode");
                }
                batchReady = true;
                if(driver.isSerialPageMode())
                    batchAllForms = true;
                formSubPageInfos.addElement(new Vector());
            } else
            {
                closeBatch();
            }
        }
    }
    Vector getFormSubPageInfo()
    {
        return !batchReady || formCount <= 0 ? null : (Vector)formSubPageInfos.elementAt(formCount - 1);
    }
    void setEndOfBatch()
    {
        batchRequest = true;
    }
    boolean isBatchExecuting()
    {
        return batchExecuting;
    }
    int executeBatch()
        throws IOException
    {
        int i = driver.getGlobalError();
        if(i < 0 || driver.isOutputFailed())
            batchReady = false;
        if(batchObject != null)
        {
            SvfrBatch svfrbatch = batchObject;
            batchObject = null;
            try
            {
                if(batchReady)
                {
                    batchExecuting = true;
                    formCount = 0;
                    batchTotalPageCount = batchAllForms ? driver.getSerialPageCount() : driver.getPageCount();
                    driver.warningOutput(null, "start batch print job");
                    if((i = svfrbatch.execute(this, 0)) >= 0)
                        driver.warningOutput(null, "end batch print job");
                    else
                        driver.warningOutput(null, (new StringBuilder()).append("error batch print job: ").append(i).toString());
                    driver.cleanup(true);
                }
            }
            finally
            {
                closeBatch(svfrbatch);
            }
        }
        return i;
    }
    private void closeBatch(SvfrBatch svfrbatch)
    {
        if(svfrbatch != null)
        {
            formCount = 0;
            formSubPageInfos.setSize(0);
            batchRequest = false;
            batchReady = false;
            batchAllForms = false;
            batchExecuting = false;
            svfrbatch.close();
        }
    }
    private void closeBatch()
    {
        SvfrBatch svfrbatch = batchObject;
        batchObject = null;
        closeBatch(svfrbatch);
    }
    protected void exceptionOccurred(Throwable throwable)
    {
        if(throwable != null && showExceptions)
        {
            throwable.printStackTrace();
            System.err.println();
        }
    }
    private int getExceptionCode(Throwable throwable)
    {
        driver.setOutputFailed(true);
        int i = driver.getExceptionCode(throwable);
        exceptionOccurred(throwable);
        return i;
    }
    public FileProperties VrGetProperties()
    {
        initInstance();
        return driver.getDriverProperties();
    }
    public Object VrGetDriverPort()
    {
        return driver0.VrGetDriverPort();
    }
    public void VrSetPreviewMode(int i, Object obj)
    {
        driver0.VrSetPreviewMode(i, obj);
    }
    public int VrGetPID()
    {
        return hashCode();
    }
    public int VrInit()
    {
        return VrInit(null);
    }
    public int VrInit(String s)
    {
        String s1 = s;
        nests = 1;
        int i;
        try
        {
            initInstance();
            deleteTemporaryFiles();
            closeBatch();
            formLoaded = false;
            execVrStackOut = false;
            execVrEndSendFax = false;
            execVrPreviewEndPage = false;
            execVrInit = false;
            formCount = 0;
            formSubPageInfos.setSize(0);
            if(s == null)
                s = encoding;
            s = driver.getDefaultEncodingName(s);
            i = driver.VrInit(s);
            if(i >= 0)
            {
                execVrInit = true;
                if(batchObject != null)
                    batchObject.VrInit(s1);
            }
        }
        catch(Throwable throwable)
        {
            throwable.printStackTrace();
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
        {
            if(s1 == null)
                driver.warningOutput(null, (new StringBuilder()).append("VrInit() ... Use Default Encoding Property [").append(encoding).append("]").toString());
            else
                driver.warningOutput(null, (new StringBuilder()).append("VrInit(\"").append(s1).append("\") ... Use Application Encoding").toString());
            driver.debugOutput(nests, i, 1, new Object[] {
                toStr(s)
            });
        }
        return driver.CheckError(i);
    }
    public int VrQuit()
    {
        long l = 0L;
        nests++;
        try
        {
            initInstance();
            driver.cleanup(true);
            if(batchObject != null)
                l = executeBatch();
            if(execVrStackOut)
            {
                execVrStackOut = false;
                driver.VrStackOut();
            }
            if(execVrEndSendFax)
            {
                execVrEndSendFax = false;
                driver.VrEndSendFax();
            }
            if(execVrPreviewEndPage)
            {
                execVrPreviewEndPage = false;
                driver.VrPreviewEndPage();
            }
            formLoaded = false;
            execVrInit = false;
            long l1 = driver.VrQuit(spoolOutput);
            if(l1 >= 0L && batchObject != null)
                batchObject.VrQuit();
            if(l >= 0L)
                l = l1;
        }
        catch(Throwable throwable)
        {
            l = getExceptionCode(throwable);
        }
        finally
        {
            deleteTemporaryFiles();
        }
        nests = 0;
        int i = (int)Math.min(2147483647L, l);
        if(driver.isDebug())
        {
            driver.debugOutput(nests, i, 2);
            if((long)i != l)
                driver.VrDebugPrint(76, 2, nests, new Object[] {
                    new Long(l)
                });
        }
        return driver.CheckError(i);
    }
    public int VrPrint()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrPrint();
            if(i >= 0 && batchObject != null)
            {
                batchObject.VrPrint();
                if(!batchAllForms)
                    i = executeBatch();
            }
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 3);
        return driver.CheckError(i);
    }
    public int VrSetForm(String s, int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            formLoaded = false;
            Object obj = null;
            switch(i)
            {
            case 0: 
            case 1: 
                obj = new BasicDriverImpl(this, driver0, properties, variables);
                break;
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
                obj = new SuperDriverImpl(this, driver0, properties, variables);
                break;
            }
            if(obj != null)
            {
                SqlDriver sqldriver = driver.getSqlDriver();
                driver.setSqlDriver(null);
                try
                {
                    j = driver.cleanup(true);
                    if(j >= 0)
                    {
                        String s1 = s;
                        if(s1 != null && s1.length() > 0 && totalPagePrefixChar.indexOf(s1.charAt(0)) >= 0)
                        {
                            s1 = s1.substring(1);
                            batchRequest = true;
                        }
                        boolean flag = batchRequest;
                        batchRequest = false;
                        if(batchObject != null)
                        {
                            if(!batchAllForms || flag)
                            {
                                j = executeBatch();
                                if(flag)
                                {
                                    driver.setSerialPageCount(0);
                                    driver.setTotalPageCount(0);
                                }
                            }
                        } else
                        if(nullOutputCommand.length() > 0)
                        {
                            ((PrintDriverWrapper) (obj)).VrComout(MessageFormat.format(nullOutputCommand, new Object[] {
                                "0"
                            }));
                            nullOutMode = false;
                        }
                        if(!flag)
                        {
                            ((PrintDriverWrapper) (obj)).setSerialPageCount(driver.getSerialPageCount());
                            ((PrintDriverWrapper) (obj)).setDetailCount(driver.getDetailCount());
                        }
                        if(j >= 0 && (j = ((PrintDriverWrapper) (obj)).VrSetForm(checkNull(s1), i)) >= 0)
                        {
                            driver = ((PrintDriverWrapper) (obj));
                            formLoaded = true;
                        }
                    }
                }
                finally
                {
                    driver.setSqlDriver(sqldriver);
                }
            } else
            {
                j = -7474;
            }
            if(j >= 0)
                if(batchExecuting)
                {
                    if(batchSerialPageCount >= 0)
                    {
                        driver.setSerialPageCount(batchSerialPageCount);
                        batchSerialPageCount = -1;
                    }
                    driver.setTotalPageCount(batchTotalPageCount);
                    formCount++;
                } else
                if(batchObject != null)
                {
                    batchObject.VrSetForm(checkNull(s), i);
                    formCount++;
                    formSubPageInfos.addElement(new Vector());
                } else
                if(nullOutputCommand.length() > 0)
                    try
                    {
                        if(!(driver instanceof BasicDriverImpl))
                        {
                            batchObject = new SvfrBatch();
                            batchObject.VrSetForm(checkNull(s), i);
                        }
                        batchSerialPageCount = driver.getSerialPageCount();
                    }
                    catch(Throwable throwable1)
                    {
                        driver.setOutputFailed(true);
                        closeBatch();
                        driver.warningOutput(throwable1, "batch mode setup error !!");
                    }
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 4, new Object[] {
                toStr(s), toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrEndSubPage()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrEndSubPage();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 5);
        return driver.CheckError(i);
    }
    public int VrEndPage()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrEndPage();
            if(i >= 0 && batchObject != null)
                batchObject.VrEndPage();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 6);
        return driver.CheckError(i);
    }
    public int VrSetDocName2(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSetDocName2(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrSetDocName2(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 7, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrEndDoc()
    {
        nests++;
        long l;
        try
        {
            initInstance();
            l = driver.VrEndDoc(spoolOutput);
            if(l >= 0L && batchObject != null)
                batchObject.VrEndDoc();
        }
        catch(Throwable throwable)
        {
            l = getExceptionCode(throwable);
        }
        nests--;
        int i = (int)Math.min(2147483647L, l);
        if(driver.isDebug())
        {
            driver.debugOutput(nests, i, 8);
            if((long)i != l)
                driver.VrDebugPrint(76, 2, nests, new Object[] {
                    new Long(l)
                });
        }
        return driver.CheckError(i);
    }
    public int VrAbortDoc()
    {
        int i = 0;
        nests++;
        try
        {
            initInstance();
            driver.setOutputFailed(true);
            closeBatch();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 9);
        return driver.CheckError(i);
    }
    public int VrPaperEject()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrPaperEject();
            if(i >= 0 && batchObject != null)
                batchObject.VrPaperEject();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 10);
        return driver.CheckError(i);
    }
    public int VrSetPrinter(String s, String s1)
    {
        nests++;
        long l;
        try
        {
            initInstance();
            formLoaded = false;
            l = driver.VrSetPrinter(checkNull(s), checkNull(s1), spoolOutput);
            if(l >= 0L && batchObject != null)
                batchObject.VrSetPrinter(checkNull(s), checkNull(s1));
        }
        catch(Throwable throwable)
        {
            l = getExceptionCode(throwable);
        }
        nests--;
        int i = (int)Math.min(2147483647L, l);
        if(driver.isDebug())
        {
            driver.debugOutput(nests, i, 11, new Object[] {
                toStr(s), toStr(s1)
            });
            if((long)i != l)
                driver.VrDebugPrint(76, 2, nests, new Object[] {
                    new Long(l)
                });
        }
        return driver.CheckError(i);
    }
    public int VrSetSpoolFileName2(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            deleteTemporaryFiles();
            i = driver.VrSetSpoolFileName2(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrSetSpoolFileName2(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 12, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrSetSpoolFileStream(OutputStream outputstream)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            deleteTemporaryFiles();
            spoolOutput = outputstream;
            spoolFile = TemporaryFile.createTempFile("svf_output_", ".tmp");
            i = driver.VrSetSpoolFileName2(spoolFile.getPath());
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 13, new Object[] {
                outputstream.getClass().getName()
            });
        return driver.CheckError(i);
    }
    public int VrSetCSVFileName(String s, int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            deleteTemporaryFiles();
            k = driver.VrSetCSVFileName(checkNull(s), i, j);
            if(k >= 0 && batchObject != null)
                batchObject.VrSetCSVFileName(checkNull(s), i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 14, new Object[] {
                toStr(s), toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrSetCSVFileStream(OutputStream outputstream, int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            deleteTemporaryFiles();
            spoolOutput = outputstream;
            File file = TemporaryFile.createTempFile("svf_output_", ".tmp");
            k = driver.VrSetCSVFileName(file.getPath(), i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 15, new Object[] {
                outputstream.getClass().getName(), toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrSetPageCount(int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            k = driver.VrSetPageCount(i, j);
            if(k >= 0 && batchObject != null)
                batchObject.VrSetPageCount(i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 16, new Object[] {
                toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrPage(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrPage(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrPage(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 17, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrCopy(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrCopy(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrCopy(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 18, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetSpoolMode(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetSpoolMode(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetSpoolMode(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 19, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetCalcMode(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetCalcMode(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetCalcMode(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 20, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSeqOut(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSeqOut(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrSeqOut(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 21, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrComout(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrComout(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrComout(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 22, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrsOut(String s, String s1)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            if(surrogatetbl != null)
                s1 = replace(s1);
            i = driver.VrsOut(checkNull(s), checkNull(s1));
            if(i >= 0 && batchObject != null)
                batchObject.VrsOut(checkNull(s), checkNull(s1));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 23, new Object[] {
                toStr(s), toStr(s1)
            });
        return driver.CheckError(i);
    }
    public int VriOut(String s, int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VriOut(checkNull(s), i);
            if(j >= 0 && batchObject != null)
                batchObject.VriOut(checkNull(s), i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 24, new Object[] {
                toStr(s), toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrlOut(String s, long l)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrlOut(checkNull(s), l);
            if(i >= 0 && batchObject != null)
                batchObject.VrlOut(checkNull(s), l);
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 25, new Object[] {
                toStr(s), toStr(l)
            });
        return driver.CheckError(i);
    }
    public int VrrOut(String s, double d)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrrOut(checkNull(s), d);
            if(i >= 0 && batchObject != null)
                batchObject.VrrOut(checkNull(s), d);
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 26, new Object[] {
                toStr(s), toStr(d)
            });
        return driver.CheckError(i);
    }
    public int VrsOutn(String s, int i, String s1)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            if(surrogatetbl != null)
                s1 = replace(s1);
            j = driver.VrsOutn(checkNull(s), i, checkNull(s1));
            if(j >= 0 && batchObject != null)
                batchObject.VrsOutn(checkNull(s), i, checkNull(s1));
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 27, new Object[] {
                toStr(s), toStr(i), toStr(s1)
            });
        return driver.CheckError(j);
    }
    public int VriOutn(String s, int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            k = driver.VriOutn(checkNull(s), i, j);
            if(k >= 0 && batchObject != null)
                batchObject.VriOutn(checkNull(s), i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 28, new Object[] {
                toStr(s), toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrlOutn(String s, int i, long l)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrlOutn(checkNull(s), i, l);
            if(j >= 0 && batchObject != null)
                batchObject.VrlOutn(checkNull(s), i, l);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 29, new Object[] {
                toStr(s), toStr(i), toStr(l)
            });
        return driver.CheckError(j);
    }
    public int VrrOutn(String s, int i, double d)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrrOutn(checkNull(s), i, d);
            if(j >= 0 && batchObject != null)
                batchObject.VrrOutn(checkNull(s), i, d);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 30, new Object[] {
                toStr(s), toStr(i), toStr(d)
            });
        return driver.CheckError(j);
    }
    public int VrAttribute(String s, String s1)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrAttribute(checkNull(s), checkNull(s1));
            if(i >= 0 && batchObject != null)
                batchObject.VrAttribute(checkNull(s), checkNull(s1));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 31, new Object[] {
                toStr(s), toStr(s1)
            });
        return driver.CheckError(i);
    }
    public int VrAttributen(String s, int i, String s1)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrAttributen(checkNull(s), i, checkNull(s1));
            if(j >= 0 && batchObject != null)
                batchObject.VrAttributen(checkNull(s), i, checkNull(s1));
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 32, new Object[] {
                toStr(s), toStr(i), toStr(s1)
            });
        return driver.CheckError(j);
    }
    public int VrGetAttribute(String s, String s1, StringBuffer stringbuffer)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrGetAttribute(checkNull(s), checkNull(s1), stringbuffer);
            if(i >= 0 && batchObject != null)
                batchObject.VrGetAttribute(checkNull(s), checkNull(s1), stringbuffer);
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 33, new Object[] {
                toStr(s), toStr(s1), stringbuffer.toString()
            });
        return driver.CheckError(i);
    }
    public int VrGetPrintFlag(StringBuffer stringbuffer)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrGetPrintFlag(stringbuffer);
            if(i >= 0 && batchObject != null)
                batchObject.VrGetPrintFlag(stringbuffer);
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 34, new Object[] {
                stringbuffer.toString()
            });
        return driver.CheckError(i);
    }
    public int VrGetStatus()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrGetStatus();
            if(i >= 0 && batchObject != null)
                batchObject.VrGetStatus();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 35);
        return driver.CheckError(i);
    }
    public int VrTest()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrTest();
            if(i >= 0 && batchObject != null)
                batchObject.VrTest();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 36);
        return driver.CheckError(i);
    }
    public int VrTestPalette()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrTestPalette();
            if(i >= 0 && batchObject != null)
                batchObject.VrTestPalette();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 37);
        return driver.CheckError(i);
    }
    public int VrAdjust(int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            k = driver.VrAdjust(i, j);
            if(k >= 0 && batchObject != null)
                batchObject.VrAdjust(i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 38, new Object[] {
                toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrAdjustd(String s, int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            k = driver.VrAdjustd(checkNull(s), i, j);
            if(k >= 0 && batchObject != null)
                batchObject.VrAdjustd(checkNull(s), i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 39, new Object[] {
                toStr(s), toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrAdjustm(String s, int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            k = driver.VrAdjustm(checkNull(s), i, j);
            if(k >= 0 && batchObject != null)
                batchObject.VrAdjustm(checkNull(s), i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 40, new Object[] {
                toStr(s), toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrStack()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrStack();
            if(i >= 0 && batchObject != null)
                batchObject.VrStack();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 41);
        return driver.CheckError(i);
    }
    public int VrStackOut()
    {
        int i = 0;
        nests++;
        try
        {
            initInstance();
            execVrStackOut = true;
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 42);
        return driver.CheckError(i);
    }
    public int VrStartSendFax(String s, String s1)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrStartSendFax(checkNull(s), checkNull(s1));
            if(i >= 0 && batchObject != null)
                batchObject.VrStartSendFax(checkNull(s), checkNull(s1));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 43, new Object[] {
                toStr(s), toStr(s1)
            });
        return driver.CheckError(i);
    }
    public int VrEndSendFax()
    {
        int i = 0;
        nests++;
        try
        {
            initInstance();
            execVrEndSendFax = true;
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 44);
        return driver.CheckError(i);
    }
    public int VrSendFaxPress(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSendFaxPress(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrSendFaxPress(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 45, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrEnablePreview(int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            k = driver.VrEnablePreview(i, j);
            if(k >= 0 && batchObject != null)
                batchObject.VrEnablePreview(i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 46, new Object[] {
                toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrPreviewStartPage()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrPreviewStartPage();
            if(i >= 0 && batchObject != null)
                batchObject.VrPreviewStartPage();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 47);
        return driver.CheckError(i);
    }
    public int VrPreviewEndPage()
    {
        int i = 0;
        nests++;
        try
        {
            initInstance();
            execVrPreviewEndPage = true;
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 48);
        return driver.CheckError(i);
    }
    public int VrEnablePrintBTN(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrEnablePrintBTN(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrEnablePrintBTN(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 49, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetSubForm(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSetSubForm(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 50, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrSetRecord(String s, int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetRecord(checkNull(s), i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 51, new Object[] {
                toStr(s), toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetColumn(String s, int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetColumn(checkNull(s), i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 52, new Object[] {
                toStr(s), toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrCheckSpace(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrCheckSpace(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 53, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrCheckColumn(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrCheckColumn(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 54, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrSetDuplex(int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            k = driver.VrSetDuplex(i, j);
            if(k >= 0 && batchObject != null)
                batchObject.VrSetDuplex(i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 55, new Object[] {
                toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrSetTray(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetTray(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetTray(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 56, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetOutputBin(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetOutputBin(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetOutputBin(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 57, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetStaple(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetStaple(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetStaple(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 58, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetSort(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetSort(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetSort(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 59, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetPunch(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetPunch(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetPunch(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 60, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrNotUseServer()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrNotUseServer();
            if(i >= 0 && batchObject != null)
                batchObject.VrNotUseServer();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 61);
        return driver.CheckError(i);
    }
    public int VrSetUseReportDirector(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetUseReportDirector(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetUseReportDirector(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 62, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetServerName(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSetServerName(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrSetServerName(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 63, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrSetUserName(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSetUserName(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrSetUserName(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 64, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrSetComputerName(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSetComputerName(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrSetComputerName(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 65, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrSetClientInfo2(String s, String s1)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSetClientInfo2(checkNull(s), checkNull(s1));
            if(i >= 0 && batchObject != null)
                batchObject.VrSetClientInfo2(checkNull(s), checkNull(s1));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 66, new Object[] {
                toStr(s), toStr(s1)
            });
        return driver.CheckError(i);
    }
    public int VrPreLoadForm(String s, int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrPreLoadForm(checkNull(s), i);
            if(j >= 0 && batchObject != null)
                batchObject.VrPreLoadForm(checkNull(s), i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 67, new Object[] {
                toStr(s), toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrGetManageNum()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = executeBatch();
            int j = driver.VrGetManageNum();
            if(i >= 0 || i == -23)
                i = j;
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 68);
        return driver.CheckError(i);
    }
    public int VrSetDocumentSaveMode(int i, int j, String s, int k)
    {
        nests++;
        int l;
        try
        {
            initInstance();
            l = driver.VrSetDocumentSaveMode(i, j, checkNull(s), k);
            if(l >= 0 && batchObject != null)
                batchObject.VrSetDocumentSaveMode(i, j, checkNull(s), k);
        }
        catch(Throwable throwable)
        {
            l = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, l, 69, new Object[] {
                toStr(i), toStr(j), toStr(s), toStr(k)
            });
        return driver.CheckError(l);
    }
    public int VrSetUseSaveMode2()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSetUseSaveMode2();
            if(i >= 0 && batchObject != null)
                batchObject.VrSetUseSaveMode2();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 70);
        return driver.CheckError(i);
    }
    public int VrSetMachineKind(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetMachineKind(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetMachineKind(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 71, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetPrinterKind(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetPrinterKind(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetPrinterKind(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 72, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetOutputVPrinter(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSetOutputVPrinter(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrSetOutputVPrinter(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 73, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrSetOutputVPrinter2(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSetOutputVPrinter2(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrSetOutputVPrinter2(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 74, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrSetOutputPrinter(String s, int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetOutputPrinter(checkNull(s), i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetOutputPrinter(checkNull(s), i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 75, new Object[] {
                toStr(s), toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetPrinterGroup(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSetPrinterGroup(checkNull(s));
            if(i >= 0 && batchObject != null)
                batchObject.VrSetPrinterGroup(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 76, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrSetPreviewAndSpool(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetPreviewAndSpool(i);
            if(j >= 0 && batchObject != null)
                batchObject.VrSetPreviewAndSpool(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 77, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetQuery(String s, String s1, int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetQuery(null, checkNull(s), checkNull(s1), i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 78, new Object[] {
                toStr(s), toStr(s1), toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrSetQueryEx(Connection connection, String s, String s1, int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetQuery(connection, checkNull(s), checkNull(s1), i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 79, new Object[] {
                connection == null ? toStr(null) : connection.getClass().getName(), toStr(s), toStr(s1), toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrCondition(String s, int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrCondition(checkNull(s), i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 80, new Object[] {
                toStr(s), toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrReport()
    {
        return VrExecQuery();
    }
    public int VrExecQuery()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            if(formLoaded)
            {
                i = driver.VrExecQuery();
            } else
            {
                SqlDriver sqldriver = driver.getSqlDriver();
                if(sqldriver == null || !sqldriver.isGenerateMode())
                {
                    i = -552;
                } else
                {
                    String s = sqldriver.getFormName();
                    int j = sqldriver.getFormMode();
                    if(s.length() == 0)
                    {
                        i = -551;
                    } else
                    {
                        driver.warningOutput(null, "automatic form load");
                        if((i = VrSetForm(s, j)) >= 0)
                            i = driver.VrExecQuery();
                    }
                }
            }
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 81);
        return driver.CheckError(i);
    }
    public int VrEndRecord()
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrEndRecord();
            if(i >= 0 && batchObject != null)
                batchObject.VrEndRecord();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 82);
        return driver.CheckError(i);
    }
    public int VrOutputQueryStream(OutputStream outputstream)
    {
        nests++;
        long l;
        try
        {
            initInstance();
            l = driver.VrOutputQueryStream(outputstream);
        }
        catch(Throwable throwable)
        {
            l = getExceptionCode(throwable);
        }
        nests--;
        int i = (int)Math.min(2147483647L, l);
        if(driver.isDebug())
        {
            driver.debugOutput(nests, i, 83, new Object[] {
                outputstream.getClass().getName()
            });
            if((long)i != l)
                driver.VrDebugPrint(76, 2, nests, new Object[] {
                    new Long(l)
                });
        }
        return driver.CheckError(i);
    }
    public int VrOutputQuery(String s)
    {
        nests++;
        long l;
        try
        {
            initInstance();
            l = driver.VrOutputQuery(checkNull(s));
            if(l >= 0L && batchObject != null)
                batchObject.VrOutputQuery(checkNull(s));
        }
        catch(Throwable throwable)
        {
            l = getExceptionCode(throwable);
        }
        nests--;
        int i = (int)Math.min(2147483647L, l);
        if(driver.isDebug())
        {
            driver.debugOutput(nests, i, 84, new Object[] {
                toStr(s)
            });
            if((long)i != l)
                driver.VrDebugPrint(76, 2, nests, new Object[] {
                    new Long(l)
                });
        }
        return driver.CheckError(i);
    }
    public int VrSetColumnLayout(String s)
    {
        nests++;
        int i;
        try
        {
            initInstance();
            i = driver.VrSetColumnLayout(checkNull(s));
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 85, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrSetColumnId(int i)
    {
        nests++;
        int j;
        try
        {
            initInstance();
            j = driver.VrSetColumnId(i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 86, new Object[] {
                toStr(i)
            });
        return driver.CheckError(j);
    }
    public int VrFileComout(String s, String s1)
    {
        int i = 0;
        nests++;
        try
        {
            initInstance();
            BufferedReader bufferedreader = (new FileLocator(checkNull(s))).getBufferedReader(checkNull(s1));
            try
            {
                do
                {
                    String s2 = bufferedreader.readLine();
                    if(s2 == null)
                        break;
                    int j = VrComout(s2);
                    if(j < 0)
                        i = j;
                } while(true);
            }
            finally
            {
                bufferedreader.close();
            }
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 87, new Object[] {
                toStr(s)
            });
        return driver.CheckError(i);
    }
    public int VrAdjustd2(int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            k = driver.VrAdjustd2(i, j);
            if(k >= 0 && batchObject != null)
                batchObject.VrAdjustd2(i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 88, new Object[] {
                toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrAdjustm2(int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            k = driver.VrAdjustm2(i, j);
            if(k >= 0 && batchObject != null)
                batchObject.VrAdjustm2(i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 89, new Object[] {
                toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrFeed(int i, int j)
    {
        nests++;
        int k;
        try
        {
            initInstance();
            k = driver.VrFeed(i, j);
            if(k >= 0 && batchObject != null)
                batchObject.VrFeed(i, j);
        }
        catch(Throwable throwable)
        {
            k = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, k, 90, new Object[] {
                toStr(i), toStr(j)
            });
        return driver.CheckError(k);
    }
    public int VrDebugPrint2(String s, int i)
    {
        int j = 0;
        nests++;
        try
        {
            initInstance();
            if(driver.isDebug())
                driver.VrDebugPrint(checkNull(s), i);
            if(j >= 0 && batchObject != null)
                batchObject.VrDebugPrint2(checkNull(s), i);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(j < 0)
            driver.debugOutput(nests, j, 91, new Object[] {
                toStr(s), toStr(i)
            });
        return driver.CheckError(j);
    }
    public String VrSetLang(String s, String s1)
    {
        String s2 = s1;
        nests++;
        try
        {
            initInstance();
            if(batchObject != null)
                batchObject.VrSetLang(checkNull(s), checkNull(s1));
        }
        catch(Throwable throwable)
        {
            getExceptionCode(throwable);
            s2 = null;
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, s2, 92, new Object[] {
                toStr(s), toStr(s1)
            });
        return s2;
    }
    public int VrSetLocale(String s)
    {
        int i = 0;
        try
        {
            currentLocale = toLocale(checkNull(s));
            driver0 = null;
            VrInit();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        if(driver.isDebug())
            driver.debugOutput(nests, i, 93, new Object[] {
                toStr(s)
            });
        return i;
    }
    public String VrGetSpoolFileName()
    {
        String s = "";
        nests++;
        try
        {
            initInstance();
            if(spoolOutput == null)
                s = driver.VrGetSpoolFileName();
        }
        catch(Throwable throwable)
        {
            getExceptionCode(throwable);
            s = null;
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, s, 94);
        return s;
    }
    public String VrGetFieldList()
    {
        String s = null;
        try
        {
            FieldObject afieldobject[] = driver.getFormObject().getAllFieldObjects();
            for(int i = 0; i < afieldobject.length; i++)
                afieldobject[i].setupDataLink();
            StringWriter stringwriter = new StringWriter();
            PrintWriter printwriter = new PrintWriter(stringwriter);
            printwriter.print(driver.getFormObject().getName());
            printwriter.print('\t');
            printwriter.print(-1);
            printwriter.print('\t');
            printwriter.print(driver.getFormObject().isPagingMode() ? 1 : 0);
            printwriter.print('\t');
            printwriter.print(driver.getFormObject().getLinkName().length() <= 0 ? 0 : 1);
            printwriter.println();
            for(int j = 0; j < afieldobject.length; j++)
            {
                FieldObject fieldobject = afieldobject[j];
                printwriter.print(fieldobject.getName());
                printwriter.print('\t');
                printwriter.print(fieldobject.getRepeatCount());
                printwriter.print('\t');
                printwriter.print(fieldobject.getDataType(0));
                printwriter.print('\t');
                printwriter.print(fieldobject.isDataLinkChild() ? 0 : Math.max(fieldobject.getBufferLength(0), fieldobject.getLength(0)));
                printwriter.println();
            }
            printwriter.flush();
            s = stringwriter.toString();
        }
        catch(Throwable throwable) { }
        return s;
    }
    public int VrGetFieldCount()
    {
        int i = 0;
        nests++;
        try
        {
            initInstance();
            FieldObject afieldobject[] = driver.getFormObject().getAllFieldObjects();
            i = afieldobject.length;
            for(int j = 0; j < afieldobject.length; j++)
                afieldobject[j].setupDataLink();
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 95);
        return i;
    }
    public int VrGetFieldName(int i, StringBuffer stringbuffer)
    {
        int j = 0;
        nests++;
        try
        {
            initInstance();
            FieldObject fieldobject = driver.getFormObject().getAllFieldObjects()[i];
            stringbuffer.setLength(0);
            stringbuffer.append(fieldobject.getName());
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 96, new Object[] {
                toStr(i), toStr(stringbuffer)
            });
        return j;
    }
    public int VrGetFieldType(int i)
    {
        int j = 0;
        nests++;
        try
        {
            initInstance();
            FieldObject fieldobject = driver.getFormObject().getAllFieldObjects()[i];
            j = fieldobject.getDataType(0);
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 97, new Object[] {
                toStr(i)
            });
        return j;
    }
    public int VrGetFieldLength(int i)
    {
        int j = 0;
        nests++;
        try
        {
            initInstance();
            FieldObject fieldobject = driver.getFormObject().getAllFieldObjects()[i];
            if(!fieldobject.isDataLinkChild())
                j = Math.max(fieldobject.getBufferLength(0), fieldobject.getLength(0));
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 98, new Object[] {
                toStr(i)
            });
        return j;
    }
    public int VrGetFieldRepeatCount(int i)
    {
        int j = 0;
        nests++;
        try
        {
            initInstance();
            FieldObject fieldobject = driver.getFormObject().getAllFieldObjects()[i];
            j = fieldobject.getRepeatCount();
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 99, new Object[] {
                toStr(i)
            });
        return j;
    }
    public int VrGetFieldRecordType(int i)
    {
        int j = 0;
        nests++;
        try
        {
            initInstance();
            FieldObject fieldobject = driver.getFormObject().getAllFieldObjects()[i];
            RecordObject recordobject = fieldobject.getRecordObject();
            if(recordobject == null)
                j = 0;
            else
            if(recordobject.isData())
                j = 1;
            else
            if(recordobject.isTotal())
                j = 2;
            else
            if(recordobject.isHeader())
                j = 3;
            else
            if(recordobject.isGrand())
                j = 4;
        }
        catch(Throwable throwable)
        {
            j = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, j, 100, new Object[] {
                toStr(i)
            });
        return j;
    }
    public int VrGetPageRecordCount()
    {
        int i = 0;
        nests++;
        try
        {
            initInstance();
            if(driver instanceof SuperDriverImpl)
            {
                SubFormObject asubformobject[] = driver.getFormObject().getSubFormObjects();
                int j = 0;
                do
                {
                    if(j >= asubformobject.length)
                        break;
                    if(asubformobject[j] instanceof RepeatSubFormObject)
                    {
                        i = ((RepeatSubFormObject)asubformobject[j]).getArraySize();
                        break;
                    }
                    j++;
                } while(true);
            }
        }
        catch(Throwable throwable)
        {
            i = getExceptionCode(throwable);
        }
        nests--;
        if(driver.isDebug())
            driver.debugOutput(nests, i, 101);
        return i;
    }
    public VR32MAIN getVR32MAIN()
    {
        return driver0;
    }
    public boolean isNullOutMode()
    {
        return nullOutMode;
    }
    public static final String cvsid = "$Revision: 7.6 $";
    private VR32MAIN driver0;
    private PrintDriverWrapper driver;
    private int nests;
    private Hashtable variables;
    private FileProperties properties;
    private boolean formLoaded;
    private String encoding;
    private String nullOutputCommand;
    private boolean nullCheckMode;
    private SvfrBatch batchObject;
    private boolean batchAllForms;
    private boolean batchReady;
    private boolean batchExecuting;
    private int batchSerialPageCount;
    private int batchTotalPageCount;
    private boolean execVrStackOut;
    private boolean execVrEndSendFax;
    private boolean execVrPreviewEndPage;
    private boolean execVrInit;
    private OutputStream spoolOutput;
    private File spoolFile;
    private Locale currentLocale;
    private Vector formSubPageInfos;
    private int formCount;
    private boolean batchRequest;
    private String totalPagePrefixChar;
    private boolean nullOutMode;
    private Hashtable surrogatetbl;
    public boolean showExceptions;
    private static final boolean TEST_DRIVER = false;
    private static final boolean VR32MAIN_DEBUG = false;
}

/*
	DECOMPILATION REPORT

	Decompiled from: H:\pleiades-e3.6-java-jre_20100926\workspace\ssw_app\online\webContent\WEB-INF\lib\svf.jar
	Total time: 430 ms
	Jad reported messages/errors:
Overlapped try statements detected. Not all exception handlers will be resolved in the method executeBatch
Overlapped try statements detected. Not all exception handlers will be resolved in the method VrQuit
Couldn't resolve all exception handlers in method VrQuit
Overlapped try statements detected. Not all exception handlers will be resolved in the method VrSetForm
Overlapped try statements detected. Not all exception handlers will be resolved in the method VrFileComout
	Exit status: 0
	Caught exceptions:
*/